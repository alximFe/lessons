create database example;
USE example;
create table users_tbl(
id int,
name varchar (40) 
);
select *from users_tbl;
